# Contributing

## Textures

- `@533k` (Seek) on Discord with the textures for:
  - [Inmis](https://modrinth.com/mod/inmis)
  - [Inventorio](https://modrinth.com/mod/inventorio)

- `@_ian` on Discord and Cobblemon Earth Team with textures for:
  - [Daily Shop](https://www.curseforge.com/minecraft/mc-mods/daily-shop)
  - [Echo Chest](https://www.curseforge.com/minecraft/mc-mods/echo-chest)
  - [Farmer's Delight](https://www.curseforge.com/minecraft/mc-mods/farmers-delight-refabricated)
  - [Iron Chests: Restocked](https://www.curseforge.com/minecraft/mc-mods/ironchests)
  - Let's do [Bakery](https://www.curseforge.com/minecraft/mc-mods/lets-do-bakery-farm-charm-compat), [Brewery](https://www.curseforge.com/minecraft/mc-mods/lets-do-brewery-farm-charm-compat), [Candlelight](https://www.curseforge.com/minecraft/mc-mods/lets-do-candlelight-farm-charm-compat), [Farm and Charm](https://www.curseforge.com/minecraft/mc-mods/lets-do-farm-charm), [Herbal Brews](https://www.curseforge.com/minecraft/mc-mods/lets-do-herbal-brews), [Vinery](https://www.curseforge.com/minecraft/mc-mods/lets-do-vinery)
  - [Numismatic Overhaul](https://www.curseforge.com/minecraft/mc-mods/numismatic-overhaul)
  - [Supplementaries](https://www.curseforge.com/minecraft/mc-mods/supplementaries)
  - [Zenith](https://www.curseforge.com/minecraft/mc-mods/zenith), [Zenith Attributes](https://www.curseforge.com/minecraft/mc-mods/zenith-attributes)

- `@mnesikos` on Discord with the textures for:
  - [Automobility](https://modrinth.com/mod/automobility)
  - [Better Advancements](https://modrinth.com/mod/better-advancements)
  - [Cobblemon Integrations](https://modrinth.com/mod/cobblemon-integrations)
  - [Cooking for Blockheads](https://modrinth.com/mod/cooking-for-blockheads)
  - [Cosmetic Armor Reworked](https://minecraft.curseforge.com/projects/cosmetic-armor-reworked)
  - [Curios API](https://modrinth.com/mod/curios)
  - [Easy Villagers](https://modrinth.com/mod/easy-villagers)
  - [Farmer's Delight](https://modrinth.com/mod/farmers-delight), [Farmer's Delight [Fabric]](https://modrinth.com/mod/farmers-delight-fabric)
  - [Realistic Horse Genetics](https://modrinth.com/mod/realistic-horse-genetics)
  - [Iron Chests](https://modrinth.com/mod/iron-chests), [Iron Chests (By: CyberAnner)](https://modrinth.com/mod/cyberanner-ironchest)
  - [Just Enough Items](https://modrinth.com/mod/jei), [Just Enough Resources](https://modrinth.com/mod/just-enough-resources-jer), [Just Enough Professions](https://modrinth.com/mod/just-enough-professions-jep)
  - [Little Logistics](https://modrinth.com/mod/little-logistics)
  - [PokeFood](https://modrinth.com/mod/pokefood)
  - [Polymorph](https://modrinth.com/mod/polymorph)
  - [Rechiseled](https://modrinth.com/mod/rechiseled)
  - [Sophisticated Core](https://www.curseforge.com/minecraft/mc-mods/sophisticated-core)
  - [Xaero's Minimap (Fair-Play)](https://modrinth.com/mod/xaeros-minimap-fair)

- @TorchTheDragon (`@torchthedragon` on Discord) with the textures for:
  - [Apotheosis](https://www.curseforge.com/minecraft/mc-mods/apotheosis)
  - [Applied Energistics 2](https://modrinth.com/mod/ae2)
  - [AppliedE](https://modrinth.com/mod/appliede)
  - [Applied Energistics 2 Wireless Terminals](https://modrinth.com/mod/applied-energistics-2-wireless-terminals)
  - [Create](https://modrinth.com/mod/create) and [Create Fabric](https://modrinth.com/mod/create-fabric)
  - [EMI](https://modrinth.com/mod/emi)
  - [Iron Furnaces](https://modrinth.com/mod/iron-furnaces)
  - [ME Requester](https://modrinth.com/mod/merequester)
  - [Overflowing Bars](https://modrinth.com/mod/overflowing-bars)
  - [ProjectE](https://www.curseforge.com/minecraft/mc-mods/projecte)
  - [Simple Voice Chat](https://modrinth.com/plugin/simple-voice-chat)
  - [Sophisticated Backpacks](https://www.curseforge.com/minecraft/mc-mods/sophisticated-backpacks), [Sophisticated Core](https://www.curseforge.com/minecraft/mc-mods/sophisticated-core), [Sophisticated Storage](https://www.curseforge.com/minecraft/mc-mods/sophisticated-storage)
  - [Tom's Simple Storage](https://modrinth.com/mod/toms-storage)
  - [Waystones](https://modrinth.com/mod/waystones)
  - [Zenith](https://modrinth.com/mod/zenith)

- `@woooferz` on Discord with the original [Cobblemon Tooltips](https://modrinth.com/resourcepack/poketips) resourcepack textures for the [Legendary Tooltips](https://modrinth.com/mod/legendary-tooltips) mod.

- XandoR (`@xandor4223` on Discord) with textures for:
  - [Cobblemon Star Academy](https://www.curseforge.com/minecraft/modpacks/cobblemon-star-academy) modpack.
  - [Cobblemon Rider](https://modrinth.com/mod/cobblemonrider1.5).

## Assets

- `u/Tonbix` on Reddit for the [16x16 Forge Icon](https://reddit.com/r/MinecraftForge/comments/p90g2w/i_drew_a_16x16_but_128x128_forge_icon/) used in the resourcepack icon.